package com.coursework.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

import com.coursework.Util.CookieUtil;
import com.coursework.Util.SessionUtil;

@WebFilter(urlPatterns = "/*")
public class AuthenticationFilter implements Filter {

    private static final String LOGIN = "/logIn";
    private static final String REGISTER = "/register";
    private static final String HOME = "/Home";
    private static final String ROOT = "/";
    private static final String ADMIN_DASHBOARD = "/admin";
    private static final String PATIENT_DASHBOARD = "/patient";
    private static final String DOCTOR_DASHBOARD = "/doctor";
    private static final String APPOINTMENT = "/appointment";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();

        // Allow static resources without authentication
        if (uri.endsWith(".css") || uri.endsWith(".js") || uri.endsWith(".png") || uri.endsWith(".jpg") || uri.endsWith(".ico")) {
            chain.doFilter(request, response);
            return;
        }

        boolean isLoggedIn = SessionUtil.getAttribute(req, "username") != null;
        String role = null;
        if (CookieUtil.getCookie(req, "role") != null) {
            role = CookieUtil.getCookie(req, "role").getValue();
        }

        // Convert to lowercase for case-insensitive comparison
        String uriLower = uri.toLowerCase();
        String homeLower = (contextPath + HOME).toLowerCase();
        String patientDashboardLower = (contextPath + PATIENT_DASHBOARD).toLowerCase();
        String doctorDashboardLower = (contextPath + DOCTOR_DASHBOARD).toLowerCase();
        String appointmentLower = (contextPath + APPOINTMENT).toLowerCase();

        if (isLoggedIn && role != null) {
            switch (role) {
                case "admin":
                    // Admin can access everything
                    chain.doFilter(request, response);
                    break;

                case "patient":
                    // Patient can access /patient, /Home, and /appointment pages
                    if (uriLower.startsWith(patientDashboardLower) || 
                        uriLower.startsWith(homeLower) || 
                        uriLower.startsWith(appointmentLower)) {
                        chain.doFilter(request, response);
                    } else {
                        res.sendRedirect(contextPath + PATIENT_DASHBOARD);
                    }
                    break;

                case "doctor":
                    // Doctor can access /doctor and /Home pages
                    if (uriLower.startsWith(doctorDashboardLower) || uriLower.startsWith(homeLower)) {
                        chain.doFilter(request, response);
                    } else {
                        res.sendRedirect(contextPath + DOCTOR_DASHBOARD);
                    }
                    break;

                default:
                    // Unknown role - redirect to login
                    res.sendRedirect(contextPath + LOGIN);
                    break;
            }
        } else {
            // Not logged in - allow access only to login, register, home, and root
            if (uri.equalsIgnoreCase(contextPath + LOGIN) ||
                uri.equalsIgnoreCase(contextPath + REGISTER) ||
                uri.equalsIgnoreCase(contextPath + HOME) ||
                uri.equalsIgnoreCase(contextPath + ROOT)) {
                chain.doFilter(request, response);
            } else {
                res.sendRedirect(contextPath + LOGIN);
            }
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // No init actions required
    }

    @Override
    public void destroy() {
        // No cleanup required
    }
}
