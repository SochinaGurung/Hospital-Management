package com.coursework.controller;

import java.io.IOException;

import com.coursework.Util.SessionUtil;
import com.coursework.model.RegisterPatientModel;
import com.coursework.service.UpdatePatientService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet to handle patient info update requests.
 */
@WebServlet(asyncSupported = true, urlPatterns = {"/updatePatient"})
public class UpdatePatientController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UpdatePatientService updatePatientService;

    public UpdatePatientController() {
        this.updatePatientService = new UpdatePatientService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        RegisterPatientModel patient = null;
        String errorMessage = null;

        // Load patient from session if available
        if (req.getSession().getAttribute("patient") != null) {
            patient = (RegisterPatientModel) SessionUtil.getAttribute(req, "patient");
            SessionUtil.removeAttribute(req, "patient");
            System.out.println("Loaded patient from session: " + patient.getPatientName());
        } else {
            String patientIdParam = req.getParameter("patientId");

            if (patientIdParam != null && !patientIdParam.trim().isEmpty()) {
                try {
                    int patientId = Integer.parseInt(patientIdParam);
                    patient = updatePatientService.getPatientById(patientId);

                    if (patient == null) {
                        errorMessage = "Patient not found with ID: " + patientId;
                        System.err.println("Patient not found: " + patientId);
                    } else {
                        System.out.println("Loaded patient from database: " + patient.getPatientName());
                    }
                } catch (NumberFormatException e) {
                    errorMessage = "Invalid Patient ID format: " + patientIdParam;
                    System.err.println("Invalid patient ID format: " + patientIdParam);
                }
            } else {
                errorMessage = "Patient ID is required to edit patient information.";
                System.err.println("No patient ID provided");
            }
        }

        if (patient != null) {
            req.setAttribute("patient", patient);
        }
        if (errorMessage != null) {
            req.setAttribute("error", errorMessage);
        }

        req.getRequestDispatcher("/WEB-INF/pages/UpdatePatient.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            System.out.println("Processing patient update request...");

            // Get parameters from form
            String patientIdParam = request.getParameter("patientId");
            String patientName = request.getParameter("patientName");
            String patientAgeParam = request.getParameter("patientAge");
            String contactNumber = request.getParameter("contactNumber");
            String patientEmail = request.getParameter("patientEmail");
            String address = request.getParameter("patientAddress");  // Adjusted to patientAddress for consistency
            String gender = request.getParameter("patientSex");       // Adjusted to patientSex for consistency

            System.out.println("Received update for patient: " + patientName);

            // Required fields validation
            if (patientIdParam == null || patientIdParam.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Patient ID is missing.");
                return;
            }

            if (patientName == null || patientName.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Patient name is required.");
                return;
            }

            if (contactNumber == null || contactNumber.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Contact number is required.");
                return;
            }

            if (patientEmail == null || patientEmail.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Patient email is required.");
                return;
            }

            if (address == null || address.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Address is required.");
                return;
            }

            if (gender == null || gender.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Gender is required.");
                return;
            }

            // Parse numeric values
            int patientId, patientAge;

            try {
                patientId = Integer.parseInt(patientIdParam);
                patientAge = Integer.parseInt(patientAgeParam);
            } catch (NumberFormatException e) {
                handleUpdateFailure(request, response, "Invalid number format in patient ID or age.");
                return;
            }

            // Additional validation
            if (patientAge < 0 || patientAge > 120) {
                handleUpdateFailure(request, response, "Patient age must be between 0 and 120.");
                return;
            }

            if (contactNumber.length() != 10 || !contactNumber.matches("\\d{10}")) {
                handleUpdateFailure(request, response, "Contact number must be exactly 10 digits.");
                return;
            }

            // Create RegisterPatientModel instance with only fields used in update
            RegisterPatientModel patient = new RegisterPatientModel();
            patient.setPatientId(patientId);
            patient.setPatientName(patientName.trim());
            patient.setPatientAge(patientAge);
            patient.setPatientSex(gender.trim());
            patient.setContactNumber(contactNumber.trim());
            patient.setEmailId(patientEmail.trim());
            patient.setPatientAddress(address.trim());

            System.out.println("Attempting to update patient: " + patient.getPatientName());

            boolean result = updatePatientService.updatePatientInfo(patient);

            if (result) {
                System.out.println("Patient updated successfully!");
                response.sendRedirect(request.getContextPath() + "/admin?success=Patient updated successfully!");
            } else {
                System.err.println("Failed to update patient in database");
                request.getSession().setAttribute("patient", patient);
                handleUpdateFailure(request, response, "Failed to update patient in database. Please try again.");
            }

        } catch (Exception e) {
            System.err.println("Unexpected error in UpdatePatientController: " + e.getMessage());
            e.printStackTrace();
            handleUpdateFailure(request, response, "An unexpected error occurred: " + e.getMessage());
        }
    }

    private void handleUpdateFailure(HttpServletRequest req, HttpServletResponse resp, String errorMessage)
            throws ServletException, IOException {
        System.err.println("Update failure: " + errorMessage);
        req.setAttribute("error", errorMessage);
        doGet(req, resp);
    }
}
