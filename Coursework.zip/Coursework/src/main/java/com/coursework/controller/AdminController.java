package com.coursework.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

import com.coursework.model.DoctorModel;
import com.coursework.service.AdminService;

/**
 * Servlet implementation for handling admin dashboard-related HTTP requests.
 * 
 * This servlet manages interactions with the AdminService to fetch doctor and patient
 * information, handle doctor updates, and manage doctor deletions.
 * It forwards requests to the appropriate JSP page or processes actions based on
 * the submitted request parameters.
 * 
 * @author
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/admin" })
public class AdminController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AdminService adminService;

    /**
     * Default constructor initializes the AdminService instance.
     */
    public AdminController() {
        this.adminService = new AdminService();
    }

    /**
     * Handles HTTP GET requests by retrieving doctor and patient information,
     * doctor/patient counts, and forwarding to the admin dashboard JSP.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            // Fetch data from AdminService
            request.setAttribute("doctorList", adminService.getAllDoctorsInfo());
            request.setAttribute("patientList", adminService.getAllPatientInfo());

            int doctorCount = adminService.getDoctorCount();
            int patientCount = adminService.getPatientCount();

            request.setAttribute("doctorCount", doctorCount);
            request.setAttribute("patientCount", patientCount);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error loading dashboard data. Please try again.");
        }

        request.getRequestDispatcher("/WEB-INF/pages/admin_portal.jsp").forward(request, response);
    }

    /**
     * Handles HTTP POST requests for actions such as updateForm and deleteDoctor.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null || action.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Invalid action specified.");
            doGet(request, response);
            return;
        }

        try {
            String doctorIdParam = request.getParameter("doctorId");
            
            if (doctorIdParam == null || doctorIdParam.trim().isEmpty()) {
                request.setAttribute("errorMessage", "Doctor ID is required.");
                doGet(request, response);
                return;
            }
            
            int doctorId = Integer.parseInt(doctorIdParam);

            switch (action.toLowerCase()) {
                case "updateform":
                    handleUpdateForm(request, response, doctorId);
                    break;

                case "deletedoctor":
                    handleDelete(request, response, doctorId);
                    break;

                default:
                    request.setAttribute("errorMessage", "Unknown action: " + action);
                    doGet(request, response);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Invalid doctor ID format.");
            doGet(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An unexpected error occurred. Please try again.");
            doGet(request, response);
        }
    }

    /**
     * Handles the update form action by setting doctor data in the session and
     * redirecting to the update page.
     */
    private void handleUpdateForm(HttpServletRequest request, HttpServletResponse response, int doctorId)
            throws IOException {
        try {
            String doctorName = request.getParameter("doctorName");
            String doctorAgeParam = request.getParameter("doctorAge");
            String doctorWeightParam = request.getParameter("doctorWeight");
            String contactNumber = request.getParameter("contactNumber");
            String doctorEmail = request.getParameter("doctorEmail");
            String specialty = request.getParameter("specialty");
            String department = request.getParameter("department");
            String workingType = request.getParameter("workingType");
            String workingHoursParam = request.getParameter("workingHours");

            // Validate required fields
            if (doctorName == null || doctorName.trim().isEmpty() ||
                doctorAgeParam == null || doctorWeightParam == null ||
                workingHoursParam == null) {
                response.sendRedirect(request.getContextPath() + "/admin?error=missingFields");
                return;
            }

            int doctorAge = Integer.parseInt(doctorAgeParam);
            int doctorWeight = Integer.parseInt(doctorWeightParam);
            int workingHours = Integer.parseInt(workingHoursParam);

            DoctorModel doctor = new DoctorModel(doctorId, doctorName, doctorAge, doctorWeight,
                    contactNumber, doctorEmail, specialty, department, workingType, workingHours);

            request.getSession().setAttribute("doctor", doctor);
            response.sendRedirect(request.getContextPath() + "/updateDoctor");
            
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin?error=invalidInput");
        }
    }

    /**
     * Handles the delete action by removing a doctor from the database and
     * providing appropriate user feedback.
     */
    private void handleDelete(HttpServletRequest request, HttpServletResponse response, int doctorId)
            throws ServletException, IOException {
        
        try {
            // Check if doctor exists before attempting deletion
            boolean doctorExists = adminService.doesDoctorExist(doctorId);
            
            if (!doctorExists) {
                request.setAttribute("errorMessage", "Doctor not found. Unable to delete.");
                doGet(request, response);
                return;
            }
            
            // Check if doctor has active appointments (optional validation)
            // boolean hasActiveAppointments = adminService.hasActiveAppointments(doctorId);
            // if (hasActiveAppointments) {
            //     request.setAttribute("errorMessage", "Cannot delete doctor with active appointments.");
            //     doGet(request, response);
            //     return;
            // }
            
            // Attempt to delete the doctor
            boolean success = adminService.deleteDoctor(doctorId);
            
            if (success) {
                request.setAttribute("successMessage", "Doctor deleted successfully!");
                System.out.println("Doctor with ID " + doctorId + " deleted successfully");
            } else {
                request.setAttribute("errorMessage", "Failed to delete doctor. Please try again.");
                System.out.println("Failed to delete doctor with ID " + doctorId);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while deleting the doctor.");
            System.out.println("Exception during doctor deletion: " + e.getMessage());
        }
        
        // Refresh the page with updated data
        doGet(request, response);
    }
}