package com.coursework.controller;

import java.io.IOException;

import com.coursework.Util.SessionUtil;
import com.coursework.model.DoctorModel;
import com.coursework.service.UpdateService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet to handle doctor info update requests.
 */
@WebServlet(asyncSupported = true, urlPatterns = {"/updateDoctor"})
public class UpdateController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Service for updating doctor information
    private UpdateService updateService;
    
    /**
     * Default constructor initializes the UpdateService instance.
     */
    public UpdateController() {
        this.updateService = new UpdateService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        DoctorModel doctor = null;
        String errorMessage = null;
        
        // First check if doctor is in session (from previous failed update)
        if (req.getSession().getAttribute("doctor") != null) {
            doctor = (DoctorModel) SessionUtil.getAttribute(req, "doctor");
            SessionUtil.removeAttribute(req, "doctor");
            System.out.println("Loaded doctor from session: " + doctor.getDoctorName());
        } else {
            // If not in session, get doctor ID from parameter and fetch from database
            String doctorIdParam = req.getParameter("doctorId");
            
            if (doctorIdParam != null && !doctorIdParam.trim().isEmpty()) {
                try {
                    int doctorId = Integer.parseInt(doctorIdParam);
                    doctor = updateService.getDoctorById(doctorId);
                    
                    if (doctor == null) {
                        errorMessage = "Doctor not found with ID: " + doctorId;
                        System.err.println("Doctor not found: " + doctorId);
                    } else {
                        System.out.println("Loaded doctor from database: " + doctor.getDoctorName());
                    }
                } catch (NumberFormatException e) {
                    errorMessage = "Invalid Doctor ID format: " + doctorIdParam;
                    System.err.println("Invalid doctor ID format: " + doctorIdParam);
                }
            } else {
                errorMessage = "Doctor ID is required to edit doctor information.";
                System.err.println("No doctor ID provided");
            }
        }
        
        // Set attributes for the JSP
        if (doctor != null) {
            req.setAttribute("doctor", doctor);
        }
        if (errorMessage != null) {
            req.setAttribute("error", errorMessage);
        }
        
        // Forward to the JSP
       
        req.getRequestDispatcher("/WEB-INF/pages/Update.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            System.out.println("Processing doctor update request...");
            
            // Get parameters from the form
            String doctorIdParam = request.getParameter("doctorId");
            String doctorName = request.getParameter("doctorName");
            String doctorAgeParam = request.getParameter("doctorAge");
            String doctorWeightParam = request.getParameter("doctorWeight");
            String contactNumber = request.getParameter("contactNumber");
            String doctorEmail = request.getParameter("doctorEmail");
            String specialty = request.getParameter("specialty");
            String department = request.getParameter("department");
            String workingType = request.getParameter("workingType");
            String workingHoursParam = request.getParameter("workingHours");
            
            // Log received parameters
            System.out.println("Received parameters:");
            System.out.println("Doctor ID: " + doctorIdParam);
            System.out.println("Doctor Name: " + doctorName);
            System.out.println("Working Type: " + workingType);
            
            // Basic validation
            if (doctorIdParam == null || doctorIdParam.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Doctor ID is missing.");
                return;
            }
            
            if (doctorName == null || doctorName.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Doctor name is required.");
                return;
            }
            
            if (doctorEmail == null || doctorEmail.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Doctor email is required.");
                return;
            }
            
            if (contactNumber == null || contactNumber.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Contact number is required.");
                return;
            }
            
            if (specialty == null || specialty.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Specialty is required.");
                return;
            }
            
            if (department == null || department.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Department is required.");
                return;
            }
            
            if (workingType == null || workingType.trim().isEmpty()) {
                handleUpdateFailure(request, response, "Working type is required.");
                return;
            }
            
            // Parse numeric values with error handling
            int doctorId, doctorAge, doctorWeight, workingHours;
            
            try {
                doctorId = Integer.parseInt(doctorIdParam);
                doctorAge = Integer.parseInt(doctorAgeParam);
                doctorWeight = Integer.parseInt(doctorWeightParam);
                workingHours = Integer.parseInt(workingHoursParam);
            } catch (NumberFormatException e) {
                handleUpdateFailure(request, response, "Invalid number format in form data. Please check age, weight, and working hours.");
                return;
            }
            
            // Additional validation
            if (doctorAge < 18 || doctorAge > 100) {
                handleUpdateFailure(request, response, "Doctor age must be between 18 and 100.");
                return;
            }
            
            if (doctorWeight < 30 || doctorWeight > 300) {
                handleUpdateFailure(request, response, "Doctor weight must be between 30 and 300 kg.");
                return;
            }
            
            if (workingHours < 1 || workingHours > 24) {
                handleUpdateFailure(request, response, "Working hours must be between 1 and 24.");
                return;
            }
            
            if (contactNumber.length() != 10 || !contactNumber.matches("\\d{10}")) {
                handleUpdateFailure(request, response, "Contact number must be exactly 10 digits.");
                return;
            }
            
            // Create DoctorModel with updated data
            DoctorModel doctor = new DoctorModel(
                doctorId, doctorName.trim(), doctorAge, doctorWeight, 
                contactNumber.trim(), doctorEmail.trim(), specialty.trim(), 
                department.trim(), workingType, workingHours
            );
            
            System.out.println("Attempting to update doctor: " + doctor.getDoctorName());
            
            // Update doctor in the database
            boolean result = updateService.updateDoctorInfo(doctor);
            
            if (result) {
                System.out.println("Doctor updated successfully!");
                // Success - redirect to admin page with success message
                response.sendRedirect(request.getContextPath() + "/admin?success=Doctor updated successfully!");
            } else {
                System.err.println("Failed to update doctor in database");
                // Store doctor in session to preserve form data
                request.getSession().setAttribute("doctor", doctor);
                handleUpdateFailure(request, response, "Failed to update doctor in database. Please try again.");
            }
            
        } catch (Exception e) {
            System.err.println("Unexpected error in UpdateController: " + e.getMessage());
            e.printStackTrace();
            handleUpdateFailure(request, response, "An unexpected error occurred: " + e.getMessage());
        }
    }
    
    /**
     * Handles update failures with custom error message.
     */
    private void handleUpdateFailure(HttpServletRequest req, HttpServletResponse resp, String errorMessage)
            throws ServletException, IOException {
        System.err.println("Update failure: " + errorMessage);
        req.setAttribute("error", errorMessage);
        // Forward to doGet to display the form with error message
        doGet(req, resp);
    }
}