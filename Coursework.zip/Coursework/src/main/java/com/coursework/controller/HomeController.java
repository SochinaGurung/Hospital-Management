package com.coursework.controller;

import java.io.IOException;

import com.coursework.Util.ValidationUtil;
import com.coursework.Util.RedirectionalUtil;
import com.coursework.Util.CookieUtil;
import com.coursework.Util.SessionUtil;

import com.coursework.model.DoctorModel;
import com.coursework.model.RegisterPatientModel;
import com.coursework.service.HomeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Handles login requests for admin, doctor, and patient.
 * Admin login is hardcoded; doctor and patient are validated through the database.
 * 
 * Updated to auto-detect user role based on login success.
 * 
 * @author sochin
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/Home" })
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ValidationUtil validationUtil;
	private RedirectionalUtil redirectionalUtil;
	private HomeService homeService;

	@Override
	public void init() throws ServletException {
		this.validationUtil = new ValidationUtil();
		this.redirectionalUtil = new RedirectionalUtil();
		this.homeService = new HomeService();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(RedirectionalUtil.loginUrl).forward(req, resp);

		req.getRequestDispatcher("/WEB-INF/pages/home.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");

		if (!validationUtil.isNullOrEmpty(username) && !validationUtil.isNullOrEmpty(password)) {

			// Admin Login
			if (username.equals("admin") && password.equals("admin")) {
				SessionUtil.setAttribute(req, "username", username);
				CookieUtil.addCookie(resp, "role", "admin", 5 * 30);
				resp.sendRedirect(req.getContextPath() + "/admin");
				return;
			}

			// Attempt Doctor Login
			DoctorModel doctor = new DoctorModel(username, password);
			Boolean doctorLoginStatus = homeService.loginDoctor(doctor);

			if (Boolean.TRUE.equals(doctorLoginStatus)) {
				SessionUtil.setAttribute(req, "username", username);
				CookieUtil.addCookie(resp, "role", "doctor", 5 * 30);
				resp.sendRedirect(req.getContextPath() + "/doctor");
				
				return;
				

			}

			// Attempt Patient Login
			RegisterPatientModel patient = new RegisterPatientModel(username, password);
			Boolean patientLoginStatus = homeService.loginPatient(patient);

			// Debugging logs — put these BEFORE redirect
			System.out.println("Trying patient login...");
			System.out.println("Username: " + username + ", Password: " + password);
			System.out.println("Patient login result: " + patientLoginStatus);

			if (Boolean.TRUE.equals(patientLoginStatus)) {
			    SessionUtil.setAttribute(req, "username", username);
			    CookieUtil.addCookie(resp, "role", "patient", 5 * 30);
			    resp.sendRedirect(req.getContextPath() + "/patient_dashboard.jsp");
			   
			    return;
			}


			// Login Failed
			handleLoginFailure(req, resp, false);

		} else {
			redirectionalUtil.setMsgAndRedirect(req, resp, "error", "Please fill all the fields!",
					RedirectionalUtil.loginUrl);
		}
	}

	/**
	 * Handles login failures by setting attributes and forwarding to the login
	 * page.
	 *
	 * @param req         HttpServletRequest object
	 * @param resp        HttpServletResponse object
	 * @param loginStatus Boolean indicating the login status
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException      if an I/O error occurs
	 */
	private void handleLoginFailure(HttpServletRequest req, HttpServletResponse resp, Boolean loginStatus)
			throws ServletException, IOException {
		String errorMessage;
		if (loginStatus == null) {
			errorMessage = "Our server is under maintenance. Please try again later!";
		} else {
			errorMessage = "User credential mismatch. Please try again!";
		}
		req.setAttribute("error", errorMessage);
		req.getRequestDispatcher(RedirectionalUtil.loginUrl).forward(req, resp);
	}
}
