package com.coursework.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Time;

import com.coursework.config.DbConfig;
import com.coursework.model.AppointmentModel;

public class AppointmentService {

    private Connection dbConn;

    public AppointmentService() {
        try {
            dbConn = DbConfig.getDbConnection();
            if (dbConn != null) {
                dbConn.setAutoCommit(false);
            }
        } catch (SQLException | ClassNotFoundException ex) {
            System.err.println("Database connection error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public Boolean addAppointment(AppointmentModel appointmentModel, String patientEmail, String doctorName) {
        if (dbConn == null) {
            System.err.println("Database connection is not available.");
            return null;
        }

        String getIdsQuery = "SELECT p.id AS patientId, d.id AS doctorId " +
                             "FROM patient p JOIN doctor d ON d.name = ? " +
                             "WHERE p.email = ?";

        String insertQuery = "INSERT INTO appointment (bookingDate, bookingTime, issues) VALUES (?, ?, ?)";

        try (
            PreparedStatement getIdsStmt = dbConn.prepareStatement(getIdsQuery);
            PreparedStatement insertStmt = dbConn.prepareStatement(insertQuery)
        ) {
            // 1. Get patientId and doctorId using JOIN
            getIdsStmt.setString(1, doctorName);
            getIdsStmt.setString(2, patientEmail);
            ResultSet rs = getIdsStmt.executeQuery();

            if (!rs.next()) {
                System.err.println("Patient or doctor not found.");
                return false;
            }

            int patientId = rs.getInt("patientId");
            int doctorId = rs.getInt("doctorId");

            // Just printing/logging (can't insert since your table doesn't support it)
            System.out.println("Patient ID: " + patientId + ", Doctor ID: " + doctorId);

            // 2. Insert appointment
            insertStmt.setDate(1, (Date) appointmentModel.getBookingDate());
            insertStmt.setTime(2, appointmentModel.getBookingTime());
            insertStmt.setString(3, appointmentModel.getIssues());

            int rows = insertStmt.executeUpdate();
            System.out.println("addAppointmentWithJoin(): rows inserted = " + rows);
            dbConn.commit();

            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error in addAppointmentWithJoin(): " + e.getMessage());
            e.printStackTrace();
            try {
                dbConn.rollback();
            } catch (Exception ignore) {}
            return false;
        }
    }

}
