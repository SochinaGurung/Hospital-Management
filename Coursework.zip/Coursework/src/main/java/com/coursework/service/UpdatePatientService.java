package com.coursework.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.coursework.model.RegisterPatientModel;

/**
 * Service class for CRUD operations on Patient
 */
public class UpdatePatientService {

    private DataSource dataSource;

    public UpdatePatientService() {
        try {
            InitialContext ctx = new InitialContext();
            dataSource = (DataSource) ctx.lookup("java:comp/env/jdbc/mydb");
        } catch (NamingException e) {
            System.err.println("Failed to initialize DataSource");
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize DataSource", e);
        }
    }

    /**
     * Gets a database connection from the DataSource.
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    private Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    /**
     * Fetches a RegisterPatientModel by ID from the database.
     * @param patientId The ID of the patient to fetch
     * @return RegisterPatientModel if found, null otherwise
     */
    public RegisterPatientModel getPatientById(int patientId) {
        String sql = "SELECT patientId, patientName, patientAge, patientSex, contactNumber, emailId, patientAddress " +
                     "FROM patients WHERE patientId = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, patientId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new RegisterPatientModel(
                        rs.getInt("patientId"),
                        rs.getString("patientName"),
                        rs.getInt("patientAge"),
                        rs.getString("patientSex"),
                        rs.getString("contactNumber"),
                        rs.getString("emailId"),
                        rs.getString("patientAddress")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching patient by ID: " + patientId);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Updates patient information in the database.
     * @param patient The patient model with updated information
     * @return true if update was successful, false otherwise
     */
    public boolean updatePatientInfo(RegisterPatientModel patient) {
        if (patient == null || patient.getPatientId() <= 0) {
            System.err.println("Invalid patient data provided for update.");
            return false;
        }

        String updateSQL = "UPDATE patients SET patientName = ?, patientAge = ?, patientSex = ?, " +
                           "contactNumber = ?, emailId = ?, patientAddress = ? WHERE patientId = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(updateSQL)) {

            stmt.setString(1, patient.getPatientName());
            stmt.setInt(2, patient.getPatientAge());
            stmt.setString(3, patient.getPatientSex());
            stmt.setString(4, patient.getContactNumber());
            stmt.setString(5, patient.getEmailId());
            stmt.setString(6, patient.getPatientAddress());
            stmt.setInt(7, patient.getPatientId());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Patient updated successfully. ID: " + patient.getPatientId());
                return true;
            } else {
                System.err.println("No rows affected. Patient ID might not exist: " + patient.getPatientId());
                return false;
            }

        } catch (SQLException e) {
            System.err.println("Error updating patient with ID: " + patient.getPatientId());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Checks if a patient exists in the database.
     * @param patientId The ID to check
     * @return true if patient exists, false otherwise
     */
    public boolean patientExists(int patientId) {
        String sql = "SELECT COUNT(*) FROM patients WHERE patientId = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, patientId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error checking if patient exists: " + patientId);
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Fetches all patients from the database.
     * @return List of all patients
     */
    public List<RegisterPatientModel> getAllPatients() {
        List<RegisterPatientModel> patients = new ArrayList<>();
        String sql = "SELECT patientId, patientName, patientAge, patientSex, contactNumber, emailId, patientAddress " +
                     "FROM patients ORDER BY patientName";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                RegisterPatientModel patient = new RegisterPatientModel(
                    rs.getInt("patientId"),
                    rs.getString("patientName"),
                    rs.getInt("patientAge"),
                    rs.getString("patientSex"),
                    rs.getString("contactNumber"),
                    rs.getString("emailId"),
                    rs.getString("patientAddress")
                );
                patients.add(patient);
            }

        } catch (SQLException e) {
            System.err.println("Error fetching all patients");
            e.printStackTrace();
        }

        return patients;
    }
}
