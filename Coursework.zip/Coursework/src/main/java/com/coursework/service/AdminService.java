package com.coursework.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.coursework.config.DbConfig;
import com.coursework.model.RegisterPatientModel;
import com.coursework.model.DoctorModel;

/**
 * Service class for interacting with the database to retrieve admin dashboard data.
 * Handles database operations for doctors and patients.
 */
public class AdminService {

	private Connection dbConn;
	private boolean isConnectionError = false;

	/**
	 * Initializes the database connection. Sets connection error flag if it fails.
	 */
	public AdminService() {
		try {
			dbConn = DbConfig.getDbConnection();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			isConnectionError = true;
		}
	}

	/**
	 * Retrieves all doctor information.
	 * @return List of DoctorModel, or empty list if connection error occurs.
	 */
	public List<DoctorModel> getAllDoctorsInfo() {
		if (isConnectionError) {
			System.out.println("Connection Error!");
			return new ArrayList<>();
		}

		String query = "SELECT doctorId, doctorName, specialty, department FROM doctor ORDER BY doctorName";
		List<DoctorModel> doctorList = new ArrayList<>();

		try (PreparedStatement stmt = dbConn.prepareStatement(query);
			 ResultSet result = stmt.executeQuery()) {

			while (result.next()) {
				DoctorModel doctor = new DoctorModel();
				doctor.setDoctorId(result.getInt("doctorId"));
				doctor.setDoctorName(result.getString("doctorName"));
				doctor.setSpecialty(result.getString("specialty"));
				doctor.setDepartment(result.getString("department"));
				doctorList.add(doctor);
			}
			return doctorList;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error fetching doctor list: " + e.getMessage());
			return new ArrayList<>();
		}
	}

	/**
	 * Retrieves all patient information.
	 * @return List of RegisterPatientModel, or empty list if connection error occurs.
	 */
	public List<RegisterPatientModel> getAllPatientInfo() {
		if (isConnectionError) {
			System.out.println("Connection Error!");
			return new ArrayList<>();
		}

		String query = "SELECT patientId, patientName, bloodGroup, contactNumber FROM patient ORDER BY patientName";
		List<RegisterPatientModel> patientList = new ArrayList<>();

		try (PreparedStatement stmt = dbConn.prepareStatement(query);
			 ResultSet result = stmt.executeQuery()) {

			while (result.next()) {
				RegisterPatientModel patient = new RegisterPatientModel();
				patient.setPatientId(result.getInt("patientId"));
				patient.setPatientName(result.getString("patientName"));
				patient.setBloodGroup(result.getString("bloodGroup"));
				patient.setContactNumber(result.getString("contactNumber"));
				patientList.add(patient);
			}
			return patientList;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error fetching patient list: " + e.getMessage());
			return new ArrayList<>();
		}
	}

	/**
	 * Updates a doctor's information based on doctorId.
	 * @param doctorModel Updated doctor data
	 * @return true if successful, false otherwise
	 */
	public boolean updateDoctor(DoctorModel doctorModel) {
		if (isConnectionError) {
			System.out.println("Cannot update doctor - connection error");
			return false;
		}

		String updateQuery = "UPDATE doctor SET doctorName = ?, doctorAge = ?, doctorWeight = ?, "
				+ "contactNumber = ?, doctorEmail = ?, specialty = ?, department = ?, "
				+ "workingType = ?, workingHours = ? WHERE doctorId = ?";

		try (PreparedStatement stmt = dbConn.prepareStatement(updateQuery)) {
			stmt.setString(1, doctorModel.getDoctorName());
			stmt.setInt(2, doctorModel.getDoctorAge());
			stmt.setInt(3, doctorModel.getDoctorWeight());
			stmt.setString(4, doctorModel.getContactNumber());
			stmt.setString(5, doctorModel.getDoctorEmail());
			stmt.setString(6, doctorModel.getSpecialty());
			stmt.setString(7, doctorModel.getDepartment());
			stmt.setString(8, doctorModel.getWorkingType());
			stmt.setInt(9, doctorModel.getWorkingHours());
			stmt.setInt(10, doctorModel.getDoctorId());

			int rowsAffected = stmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error updating doctor: " + e.getMessage());
			return false;
		}
	}

	/**
	 * Checks if a doctor exists in the database.
	 * @param doctorId The ID of the doctor to check
	 * @return true if doctor exists, false otherwise
	 */
	public boolean doesDoctorExist(int doctorId) {
		if (isConnectionError) {
			return false;
		}

		String query = "SELECT COUNT(*) FROM doctor WHERE doctorId = ?";
		
		try (PreparedStatement stmt = dbConn.prepareStatement(query)) {
			stmt.setInt(1, doctorId);
			
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error checking if doctor exists: " + e.getMessage());
		}
		return false;
	}

	/**
	 * Deletes a doctor by doctorId with enhanced error handling.
	 * @param doctorId The ID of the doctor to delete
	 * @return true if deleted successfully, false otherwise
	 */
	public boolean deleteDoctor(int doctorId) {
		if (isConnectionError) {
			System.out.println("Cannot delete doctor - connection error");
			return false;
		}

		// First check if doctor exists
		if (!doesDoctorExist(doctorId)) {
			System.out.println("Doctor with ID " + doctorId + " does not exist");
			return false;
		}

		String deleteQuery = "DELETE FROM doctor WHERE doctorId = ?";

		try (PreparedStatement stmt = dbConn.prepareStatement(deleteQuery)) {
			stmt.setInt(1, doctorId);
			
			int rowsAffected = stmt.executeUpdate();
			
			if (rowsAffected > 0) {
				System.out.println("Successfully deleted doctor with ID: " + doctorId);
				return true;
			} else {
				System.out.println("No rows affected when deleting doctor with ID: " + doctorId);
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error deleting doctor: " + e.getMessage());
			return false;
		}
	}

	/**
	 * Optional: Check if doctor has active appointments (for safer deletion)
	 * Uncomment and implement if you have an appointments table
	 */
	/*
	public boolean hasActiveAppointments(int doctorId) {
		if (isConnectionError) {
			return false;
		}

		String query = "SELECT COUNT(*) FROM appointments WHERE doctorId = ? AND appointmentDate >= CURDATE()";
		
		try (PreparedStatement stmt = dbConn.prepareStatement(query)) {
			stmt.setInt(1, doctorId);
			
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error checking active appointments: " + e.getMessage());
		}
		return false;
	}
	*/

	/**
	 * Returns the total number of doctors.
	 * @return doctor count
	 */
	public int getDoctorCount() {
		if (isConnectionError) {
			System.out.println("Cannot get doctor count - connection error");
			return 0;
		}

		String query = "SELECT COUNT(*) AS total FROM doctor";
		try (PreparedStatement stmt = dbConn.prepareStatement(query);
			 ResultSet rs = stmt.executeQuery()) {
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error getting doctor count: " + e.getMessage());
		}
		return 0;
	}

	/**
	 * Returns the total number of patients.
	 * @return patient count
	 */
	public int getPatientCount() {
		if (isConnectionError) {
			System.out.println("Cannot get patient count - connection error");
			return 0;
		}

		String query = "SELECT COUNT(*) AS total FROM patient";
		try (PreparedStatement stmt = dbConn.prepareStatement(query);
			 ResultSet rs = stmt.executeQuery()) {
			if (rs.next()) {
				return rs.getInt("total");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error getting patient count: " + e.getMessage());
		}
		return 0;
	}

	/**
	 * Close database connection when service is no longer needed
	 */
	public void closeConnection() {
		if (dbConn != null) {
			try {
				dbConn.close();
				System.out.println("Database connection closed successfully");
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Error closing database connection: " + e.getMessage());
			}
		}
	}
}