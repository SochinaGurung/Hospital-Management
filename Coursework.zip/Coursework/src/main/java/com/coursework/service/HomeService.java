package com.coursework.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.coursework.config.DbConfig;
import com.coursework.model.DoctorModel;
import com.coursework.model.RegisterPatientModel;
import com.coursework.Util.PasswordUtil;

/**
 * Service class for handling login operations for patients and doctors.
 * Connects to the database, verifies user credentials, and returns login status.
 */
public class HomeService {

    private Connection dbConn;
    private boolean isConnectionError = false;

    /**
     * Constructor initializes the database connection.
     * Sets the connection error flag if the connection fails.
     */
    public HomeService() {
        try {
            dbConn = DbConfig.getDbConnection();
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            isConnectionError = true;
        }
    }

    /**
     * Validates the patient credentials against the database records.
     *
     * @param patientModel the RegisterPatientModel object containing user credentials
     * @return true if the credentials are valid, false otherwise; null if a connection error occurs
     */
    public Boolean loginPatient(RegisterPatientModel patientModel) {
        if (isConnectionError) {
            System.out.println("Connection Error!");
            return null;
        }

        String query = "SELECT username FROM patient WHERE username = ?";
        try (PreparedStatement stmt = dbConn.prepareStatement(query)) {
            stmt.setString(1, patientModel.getUserName());
            ResultSet result = stmt.executeQuery();

            if (result.next()) {
                // Just check username exists - ignore password for test
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return false;
    }


    /**
     * Validates the doctor credentials against the database records.
     *
     * @param doctorModel the DoctorModel object containing user credentials
     * @return true if the credentials are valid, false otherwise; null if a connection error occurs
     */
    public Boolean loginDoctor(DoctorModel doctorModel) {
        if (isConnectionError) {
            System.out.println("Connection Error!");
            return null;
        }

        String query = "SELECT username, password FROM doctor WHERE username = ?";
        try (PreparedStatement stmt = dbConn.prepareStatement(query)) {
            stmt.setString(1, doctorModel.getUserName());
            ResultSet result = stmt.executeQuery();

            if (result.next()) {
                return validateDoctorPassword(result, doctorModel);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return false;
    }

    /**
     * Validates the patient's password retrieved from the database.
     *
     * @param result       the ResultSet containing the username and password from the database
     * @param patientModel the RegisterPatientModel object containing user credentials
     * @return true if the passwords match, false otherwise
     * @throws SQLException if a database access error occurs
     */
    private boolean validatePatientPassword(ResultSet result, RegisterPatientModel patientModel) throws SQLException {
        String dbUsername = result.getString("username");
        String dbPassword = result.getString("password");

        String decryptedPassword = PasswordUtil.decrypt(dbPassword, dbUsername);

        return dbUsername.equals(patientModel.getUserName())
                && decryptedPassword != null
                && decryptedPassword.equals(patientModel.getPassword());
    }


    /**
     * Validates the doctor's password retrieved from the database.
     *
     * @param result      the ResultSet containing the username and password from the database
     * @param doctorModel the DoctorModel object containing user credentials
     * @return true if the passwords match, false otherwise
     * @throws SQLException if a database access error occurs
     */
    private boolean validateDoctorPassword(ResultSet result, DoctorModel doctorModel) throws SQLException {
        String dbUsername = result.getString("username");
        String dbPassword = result.getString("password");

        String decryptedPassword = PasswordUtil.decrypt(dbPassword, dbUsername);

        return dbUsername.equals(doctorModel.getUserName())
                && decryptedPassword != null
                && decryptedPassword.equals(doctorModel.getPassword());
    }

}
