package com.coursework.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.coursework.config.DbConfig;
import com.coursework.model.DoctorModel;

/**
 * Service class for CRUD operations on Doctor
 */
public class UpdateService {
    
    /**
     * Fetches a DoctorModel by ID from the database.
     * @param doctorId The ID of the doctor to fetch
     * @return DoctorModel if found, null otherwise
     */
    public DoctorModel getDoctorById(int doctorId) {
        String sql = "SELECT doctorId, doctorName, doctorAge, doctorWeight, contactNumber, " +
                    "doctorEmail, specialty, department, workingType, workingHours " +
                    "FROM doctor WHERE doctorId = ?";
        
        try (Connection dbConn = DbConfig.getDbConnection();
             PreparedStatement ps = dbConn.prepareStatement(sql)) {
            
            ps.setInt(1, doctorId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new DoctorModel(
                        rs.getInt("doctorId"),
                        rs.getString("doctorName"),
                        rs.getInt("doctorAge"),
                        rs.getInt("doctorWeight"),
                        rs.getString("contactNumber"),
                        rs.getString("doctorEmail"),
                        rs.getString("specialty"),
                        rs.getString("department"),
                        rs.getString("workingType"),
                        rs.getInt("workingHours")
                    );
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error fetching doctor by ID: " + doctorId);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Updates doctor information in the database.
     * @param doctor The doctor model with updated information
     * @return true if update was successful, false otherwise
     */
    public boolean updateDoctorInfo(DoctorModel doctor) {
        if (doctor == null || doctor.getDoctorId() <= 0) {
            System.err.println("Invalid doctor data provided for update.");
            return false;
        }

        String updateSQL = "UPDATE doctor SET doctorName = ?, doctorAge = ?, doctorWeight = ?, " +
                          "contactNumber = ?, doctorEmail = ?, specialty = ?, department = ?, " +
                          "workingType = ?, workingHours = ? WHERE doctorId = ?";

        try (Connection dbConn = DbConfig.getDbConnection();
             PreparedStatement stmt = dbConn.prepareStatement(updateSQL)) {
            
            stmt.setString(1, doctor.getDoctorName());
            stmt.setInt(2, doctor.getDoctorAge());
            stmt.setInt(3, doctor.getDoctorWeight());
            stmt.setString(4, doctor.getContactNumber());
            stmt.setString(5, doctor.getDoctorEmail());
            stmt.setString(6, doctor.getSpecialty());
            stmt.setString(7, doctor.getDepartment());
            stmt.setString(8, doctor.getWorkingType());
            stmt.setInt(9, doctor.getWorkingHours());
            stmt.setInt(10, doctor.getDoctorId());

            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Doctor updated successfully. ID: " + doctor.getDoctorId());
                return true;
            } else {
                System.err.println("No rows affected. Doctor ID might not exist: " + doctor.getDoctorId());
                return false;
            }
            
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error updating doctor with ID: " + doctor.getDoctorId());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Checks if a doctor exists in the database
     * @param doctorId The ID to check
     * @return true if doctor exists, false otherwise
     */
    public boolean doctorExists(int doctorId) {
        String sql = "SELECT COUNT(*) FROM doctor WHERE doctorId = ?";
        
        try (Connection dbConn = DbConfig.getDbConnection();
             PreparedStatement ps = dbConn.prepareStatement(sql)) {
            
            ps.setInt(1, doctorId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error checking if doctor exists: " + doctorId);
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Fetches all doctors from the database
     * @return List of all doctors
     */
    public List<DoctorModel> getAllDoctors() {
        List<DoctorModel> doctors = new ArrayList<>();
        String sql = "SELECT doctorId, doctorName, doctorAge, doctorWeight, contactNumber, " +
                    "doctorEmail, specialty, department, workingType, workingHours " +
                    "FROM doctor ORDER BY doctorName";
        
        try (Connection dbConn = DbConfig.getDbConnection();
             PreparedStatement ps = dbConn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                DoctorModel doctor = new DoctorModel(
                    rs.getInt("doctorId"),
                    rs.getString("doctorName"),
                    rs.getInt("doctorAge"),
                    rs.getInt("doctorWeight"),
                    rs.getString("contactNumber"),
                    rs.getString("doctorEmail"),
                    rs.getString("specialty"),
                    rs.getString("department"),
                    rs.getString("workingType"),
                    rs.getInt("workingHours")
                );
                doctors.add(doctor);
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error fetching all doctors");
            e.printStackTrace();
        }
        return doctors;
    }
}