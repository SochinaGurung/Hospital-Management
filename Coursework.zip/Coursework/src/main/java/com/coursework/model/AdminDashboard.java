package com.coursework.model;

public class AdminDashboard {

}
